# Sistema de Gestión de Activos Empresariales

Aplicación web en Java (Jakarta EE 10, JDK 21) para registrar los activos de una empresa
(equipos, mobiliario, etc.), asignarlos a empleados y consultar su estado.
Proyecto del curso de Aplicaciones Web Empresariales (UTP) — segundo avance.

## Arquitectura

MVC en capas: `controller` (Servlets) → `service` (reglas de negocio) → `dao` (JDBC) → MySQL 8.
Las vistas son JSP + JSTL dentro de `WEB-INF/views`, así solo se acceden a través de un controlador.

| Paquete | Contenido |
| --- | --- |
| `config` | `ConexionDB`: lee `db.properties` y entrega conexiones JDBC |
| `model` | POJOs: `Activo`, `Empleado`, `Asignacion`, `Usuario`, `Categoria`, `Departamento` |
| `dao` | Acceso a datos con `PreparedStatement` |
| `service` | Reglas de negocio; asignar y devolver activos usan transacciones |
| `controller` | `ActivoServlet`, `EmpleadoServlet`, `AsignacionServlet`, `LoginServlet`, `LogoutServlet` |
| `filter` | `AuthFilter` (exige sesión) y `EncodingFilter` (UTF-8) |
| `util` | Conversión de formularios, sesión y hash de contraseñas |

Patrones aplicados: MVC, DAO, capa de servicio, POJO, Post/Redirect/Get.

## Funcionalidad

- Inicio de sesión con roles `ADMIN` y `GESTOR`.
- Activos: listar con búsqueda, registrar, editar, enviar a mantenimiento, habilitar y dar de baja (solo `ADMIN`).
- Empleados: listar y registrar (registrar solo `ADMIN`).
- Asignaciones: asignar un activo disponible a un empleado y registrar su devolución; el historial se conserva.
  El estado del activo cambia solo (DISPONIBLE ⇄ ASIGNADO).

## Requisitos

- JDK 21
- Apache Maven 3.9+ (viene integrado en NetBeans)
- MySQL 8
- Apache Tomcat 10.1 (permitido para este avance). El servidor elegido para la versión final es WildFly (ver Documento Técnico, sección 2.2).
- NetBeans con soporte Java Web / Jakarta EE

## Cómo ejecutarlo

1. **Crear la base de datos.** Abre `sql/gestion_activos.sql` en MySQL Workbench y ejecútalo completo
   (o `mysql -u root -p < sql/gestion_activos.sql`). Crea la base `gestion_activos` con datos de prueba.
2. **Configurar la conexión.** Edita `src/main/resources/db.properties` y cambia `db.password`
   por la contraseña de tu MySQL.
3. **Abrir en NetBeans.** File → Open Project → selecciona la carpeta `gestion-activos`.
   La primera vez, NetBeans descarga las dependencias de Maven (necesita internet).
4. **Registrar Tomcat.** Tools → Servers → Add Server → Apache Tomcat or TomEE, y elige la carpeta de Tomcat 10.1.
5. **Ejecutar.** Clic derecho sobre el proyecto → Run. Abre `http://localhost:8080/gestion-activos/`.

Por línea de comandos: `mvn clean package` genera `target/gestion-activos.war`, que se copia a la carpeta `webapps` de Tomcat.

## Usuarios de prueba

| Usuario | Contraseña | Rol |
| --- | --- | --- |
| admin | admin123 | ADMIN |
| gestor | gestor123 | GESTOR |

## Estructura

```
gestion-activos/
├── pom.xml
├── sql/gestion_activos.sql
└── src/main/
    ├── java/pe/utp/activos/{config,model,dao,service,controller,filter,util}
    ├── resources/db.properties
    └── webapp/
        ├── index.jsp, css/estilo.css
        └── WEB-INF/{web.xml, views/}
```

## Pendiente para el siguiente avance

- Servicios RESTful (JAX-RS) sobre las mismas capas de servicio.
- Migración al servidor WildFly.
- Pruebas automatizadas.
