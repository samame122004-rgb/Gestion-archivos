-- ============================================================
-- Sistema de Gestión de Activos Empresariales - MySQL 8
-- Ejecutar completo en MySQL Workbench o con: mysql -u root -p < gestion_activos.sql
-- ============================================================
DROP DATABASE IF EXISTS gestion_activos;
CREATE DATABASE gestion_activos
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gestion_activos;

CREATE TABLE departamento (
  id_departamento INT AUTO_INCREMENT PRIMARY KEY,
  nombre          VARCHAR(80) NOT NULL UNIQUE
);

CREATE TABLE empleado (
  id_empleado     INT AUTO_INCREMENT PRIMARY KEY,
  dni             CHAR(8)      NOT NULL UNIQUE,
  nombres         VARCHAR(80)  NOT NULL,
  apellidos       VARCHAR(80)  NOT NULL,
  correo          VARCHAR(120) NOT NULL UNIQUE,
  cargo           VARCHAR(80),
  id_departamento INT NOT NULL,
  CONSTRAINT fk_empleado_departamento
    FOREIGN KEY (id_departamento) REFERENCES departamento (id_departamento)
);

CREATE TABLE usuario (
  id_usuario    INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(40)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  rol           ENUM('ADMIN','GESTOR') NOT NULL DEFAULT 'GESTOR',
  id_empleado   INT NULL,
  CONSTRAINT fk_usuario_empleado
    FOREIGN KEY (id_empleado) REFERENCES empleado (id_empleado)
);

CREATE TABLE categoria (
  id_categoria INT AUTO_INCREMENT PRIMARY KEY,
  nombre       VARCHAR(60) NOT NULL UNIQUE
);

CREATE TABLE activo (
  id_activo         INT AUTO_INCREMENT PRIMARY KEY,
  codigo            VARCHAR(20)  NOT NULL UNIQUE,
  nombre            VARCHAR(100) NOT NULL,
  marca             VARCHAR(60),
  modelo            VARCHAR(60),
  nro_serie         VARCHAR(60),
  id_categoria      INT NOT NULL,
  estado            ENUM('DISPONIBLE','ASIGNADO','MANTENIMIENTO','BAJA')
                    NOT NULL DEFAULT 'DISPONIBLE',
  fecha_adquisicion DATE,
  valor             DECIMAL(10,2),
  CONSTRAINT fk_activo_categoria
    FOREIGN KEY (id_categoria) REFERENCES categoria (id_categoria)
);

CREATE TABLE asignacion (
  id_asignacion    INT AUTO_INCREMENT PRIMARY KEY,
  id_activo        INT  NOT NULL,
  id_empleado      INT  NOT NULL,
  fecha_asignacion DATE NOT NULL,
  fecha_devolucion DATE NULL,
  observacion      VARCHAR(255),
  CONSTRAINT fk_asignacion_activo
    FOREIGN KEY (id_activo)   REFERENCES activo (id_activo),
  CONSTRAINT fk_asignacion_empleado
    FOREIGN KEY (id_empleado) REFERENCES empleado (id_empleado)
);

-- ------------------------------------------------------------
-- Datos de prueba
-- ------------------------------------------------------------
INSERT INTO departamento (nombre) VALUES
  ('Tecnología'), ('Administración'), ('Logística');

INSERT INTO empleado (dni, nombres, apellidos, correo, cargo, id_departamento) VALUES
  ('70123456', 'Lucía', 'Ramos Torres', 'lramos@empresa.com',   'Analista de sistemas',     1),
  ('71234567', 'Diego', 'Paredes Vega', 'dparedes@empresa.com', 'Asistente administrativo', 2),
  ('72345678', 'Marta', 'Quispe Rojas', 'mquispe@empresa.com',  'Jefa de almacén',          3);

-- Contraseñas (SHA-256): admin -> admin123 | gestor -> gestor123
INSERT INTO usuario (username, password_hash, rol, id_empleado) VALUES
  ('admin',  '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'ADMIN',  1),
  ('gestor', '18f2b94d784d03c222cb7c47148cdb8457f1ef3eaf3e317711f25d55747f6a35', 'GESTOR', 2);

INSERT INTO categoria (nombre) VALUES
  ('Equipo de cómputo'), ('Mobiliario'), ('Vehículo'), ('Herramienta');

INSERT INTO activo (codigo, nombre, marca, modelo, nro_serie, id_categoria, estado, fecha_adquisicion, valor) VALUES
  ('ACT-0001', 'Laptop',              'Lenovo',       'ThinkPad E14',  'SN-A1001', 1, 'ASIGNADO',      '2025-03-10', 3200.00),
  ('ACT-0002', 'Monitor 24"',         'Samsung',      'S24F350',       'SN-B2002', 1, 'DISPONIBLE',    '2025-04-02',  650.00),
  ('ACT-0003', 'Escritorio ejecutivo','Muebles Lima', 'EJ-120',        NULL,       2, 'ASIGNADO',      '2024-11-20',  480.00),
  ('ACT-0004', 'Impresora láser',     'HP',           'LaserJet M404', 'SN-C3003', 1, 'MANTENIMIENTO', '2024-08-15', 1100.00);

INSERT INTO asignacion (id_activo, id_empleado, fecha_asignacion, observacion) VALUES
  (1, 1, '2025-03-12', 'Entrega con cargador y mochila'),
  (3, 2, '2024-11-25', 'Puesto de trabajo en oficina 2');
