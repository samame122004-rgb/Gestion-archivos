package pe.utp.activos.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import pe.utp.activos.model.Activo;
import pe.utp.activos.service.ActivoService;
import pe.utp.activos.service.ServicioException;
import pe.utp.activos.util.Formularios;
import pe.utp.activos.util.Sesion;

/**
 * Controlador del módulo de activos.
 * GET  /activos                -> listado (con búsqueda ?q=)
 * GET  /activos?action=nuevo   -> formulario vacío
 * GET  /activos?action=editar&id=N
 * POST /activos?action=guardar -> registra o actualiza
 * POST /activos?action=estado  -> mantenimiento / habilitar / baja
 */
@WebServlet("/activos")
public class ActivoServlet extends HttpServlet {

    private static final String LISTAR = "/WEB-INF/views/activos/listar.jsp";
    private static final String FORMULARIO = "/WEB-INF/views/activos/formulario.jsp";

    private final ActivoService service = new ActivoService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if ("nuevo".equals(action)) {
                mostrarFormulario(req, resp, new Activo());
            } else if ("editar".equals(action)) {
                mostrarFormulario(req, resp, service.buscar(Formularios.entero(req.getParameter("id"), 0)));
            } else {
                String q = Formularios.texto(req.getParameter("q"));
                req.setAttribute("q", q);
                req.setAttribute("activos", service.listar(q));
                req.getRequestDispatcher(LISTAR).forward(req, resp);
            }
        } catch (ServicioException e) {
            Sesion.error(req, e.getMessage());
            resp.sendRedirect(req.getContextPath() + "/activos");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if ("estado".equals(action)) {
            cambiarEstado(req, resp);
        } else {
            guardar(req, resp);
        }
    }

    private void guardar(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Activo a = new Activo();
        a.setIdActivo(Formularios.entero(req.getParameter("idActivo"), 0));
        a.setCodigo(Formularios.texto(req.getParameter("codigo")));
        a.setNombre(Formularios.texto(req.getParameter("nombre")));
        a.setMarca(Formularios.texto(req.getParameter("marca")));
        a.setModelo(Formularios.texto(req.getParameter("modelo")));
        a.setNroSerie(Formularios.texto(req.getParameter("nroSerie")));
        a.setIdCategoria(Formularios.entero(req.getParameter("idCategoria"), 0));
        a.setFechaAdquisicion(Formularios.fecha(req.getParameter("fechaAdquisicion")));
        a.setValor(Formularios.decimal(req.getParameter("valor")));
        try {
            service.guardar(a);
            Sesion.exito(req, "Activo guardado correctamente");
            resp.sendRedirect(req.getContextPath() + "/activos"); // Post/Redirect/Get
        } catch (ServicioException e) {
            req.setAttribute("error", e.getMessage());
            mostrarFormulario(req, resp, a); // conserva lo que el usuario escribió
        }
    }

    private void cambiarEstado(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        int id = Formularios.entero(req.getParameter("id"), 0);
        String estado = req.getParameter("estado");
        if (Activo.BAJA.equals(estado) && !Sesion.esAdmin(req)) {
            Sesion.error(req, "Solo un administrador puede dar de baja un activo");
        } else {
            try {
                service.cambiarEstado(id, estado);
                Sesion.exito(req, "Estado actualizado a " + estado);
            } catch (ServicioException e) {
                Sesion.error(req, e.getMessage());
            }
        }
        resp.sendRedirect(req.getContextPath() + "/activos");
    }

    private void mostrarFormulario(HttpServletRequest req, HttpServletResponse resp, Activo activo)
            throws ServletException, IOException {
        try {
            req.setAttribute("activo", activo);
            req.setAttribute("categorias", service.listarCategorias());
            req.getRequestDispatcher(FORMULARIO).forward(req, resp);
        } catch (ServicioException e) {
            Sesion.error(req, e.getMessage());
            resp.sendRedirect(req.getContextPath() + "/activos");
        }
    }
}
