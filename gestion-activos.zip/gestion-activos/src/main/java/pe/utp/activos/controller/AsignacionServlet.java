package pe.utp.activos.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDate;
import pe.utp.activos.service.ActivoService;
import pe.utp.activos.service.AsignacionService;
import pe.utp.activos.service.EmpleadoService;
import pe.utp.activos.service.ServicioException;
import pe.utp.activos.util.Formularios;
import pe.utp.activos.util.Sesion;

/**
 * Controlador de asignaciones.
 * GET  /asignaciones                -> historial (vigentes primero)
 * GET  /asignaciones?action=nueva   -> formulario para asignar un activo disponible
 * POST /asignaciones?action=asignar
 * POST /asignaciones?action=devolver
 */
@WebServlet("/asignaciones")
public class AsignacionServlet extends HttpServlet {

    private static final String LISTAR = "/WEB-INF/views/asignaciones/listar.jsp";
    private static final String FORMULARIO = "/WEB-INF/views/asignaciones/formulario.jsp";

    private final AsignacionService service = new AsignacionService();
    private final ActivoService activoService = new ActivoService();
    private final EmpleadoService empleadoService = new EmpleadoService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            if ("nueva".equals(req.getParameter("action"))) {
                mostrarFormulario(req, resp);
            } else {
                req.setAttribute("asignaciones", service.listar());
                req.setAttribute("hoy", LocalDate.now());
                req.getRequestDispatcher(LISTAR).forward(req, resp);
            }
        } catch (ServicioException e) {
            req.setAttribute("error", e.getMessage());
            req.getRequestDispatcher(LISTAR).forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if ("devolver".equals(action)) {
                service.devolver(Formularios.entero(req.getParameter("idAsignacion"), 0),
                        Formularios.fecha(req.getParameter("fechaDevolucion")));
                Sesion.exito(req, "Devolución registrada: el activo vuelve a estar disponible");
            } else {
                service.asignar(Formularios.entero(req.getParameter("idActivo"), 0),
                        Formularios.entero(req.getParameter("idEmpleado"), 0),
                        Formularios.fecha(req.getParameter("fechaAsignacion")),
                        Formularios.texto(req.getParameter("observacion")));
                Sesion.exito(req, "Activo asignado correctamente");
            }
        } catch (ServicioException e) {
            if ("devolver".equals(action)) {
                Sesion.error(req, e.getMessage());
            } else {
                req.setAttribute("error", e.getMessage());
                mostrarFormulario(req, resp);
                return;
            }
        }
        resp.sendRedirect(req.getContextPath() + "/asignaciones");
    }

    private void mostrarFormulario(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            req.setAttribute("activos", activoService.listarDisponibles());
            req.setAttribute("empleados", empleadoService.listar());
            req.setAttribute("hoy", LocalDate.now());
            req.getRequestDispatcher(FORMULARIO).forward(req, resp);
        } catch (ServicioException e) {
            Sesion.error(req, e.getMessage());
            resp.sendRedirect(req.getContextPath() + "/asignaciones");
        }
    }
}
