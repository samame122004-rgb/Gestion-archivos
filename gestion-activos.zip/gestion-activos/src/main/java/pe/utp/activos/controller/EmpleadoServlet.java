package pe.utp.activos.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import pe.utp.activos.model.Empleado;
import pe.utp.activos.service.EmpleadoService;
import pe.utp.activos.service.ServicioException;
import pe.utp.activos.util.Formularios;
import pe.utp.activos.util.Sesion;

/** Controlador de empleados. Listar lo ve cualquier usuario; registrar solo el ADMIN. */
@WebServlet("/empleados")
public class EmpleadoServlet extends HttpServlet {

    private static final String LISTAR = "/WEB-INF/views/empleados/listar.jsp";
    private static final String FORMULARIO = "/WEB-INF/views/empleados/formulario.jsp";

    private final EmpleadoService service = new EmpleadoService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            if ("nuevo".equals(req.getParameter("action"))) {
                if (!Sesion.esAdmin(req)) {
                    Sesion.error(req, "Solo un administrador puede registrar empleados");
                    resp.sendRedirect(req.getContextPath() + "/empleados");
                    return;
                }
                mostrarFormulario(req, resp, new Empleado());
            } else {
                req.setAttribute("empleados", service.listar());
                req.getRequestDispatcher(LISTAR).forward(req, resp);
            }
        } catch (ServicioException e) {
            req.setAttribute("error", e.getMessage());
            req.getRequestDispatcher(LISTAR).forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!Sesion.esAdmin(req)) {
            Sesion.error(req, "Solo un administrador puede registrar empleados");
            resp.sendRedirect(req.getContextPath() + "/empleados");
            return;
        }
        Empleado e = new Empleado();
        e.setDni(Formularios.texto(req.getParameter("dni")));
        e.setNombres(Formularios.texto(req.getParameter("nombres")));
        e.setApellidos(Formularios.texto(req.getParameter("apellidos")));
        e.setCorreo(Formularios.texto(req.getParameter("correo")));
        e.setCargo(Formularios.texto(req.getParameter("cargo")));
        e.setIdDepartamento(Formularios.entero(req.getParameter("idDepartamento"), 0));
        try {
            service.registrar(e);
            Sesion.exito(req, "Empleado registrado correctamente");
            resp.sendRedirect(req.getContextPath() + "/empleados");
        } catch (ServicioException ex) {
            req.setAttribute("error", ex.getMessage());
            mostrarFormulario(req, resp, e);
        }
    }

    private void mostrarFormulario(HttpServletRequest req, HttpServletResponse resp, Empleado empleado)
            throws ServletException, IOException {
        try {
            req.setAttribute("empleado", empleado);
            req.setAttribute("departamentos", service.listarDepartamentos());
            req.getRequestDispatcher(FORMULARIO).forward(req, resp);
        } catch (ServicioException ex) {
            Sesion.error(req, ex.getMessage());
            resp.sendRedirect(req.getContextPath() + "/empleados");
        }
    }
}
