package pe.utp.activos.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import pe.utp.activos.model.Usuario;
import pe.utp.activos.service.AutenticacionService;
import pe.utp.activos.service.ServicioException;
import pe.utp.activos.util.Formularios;
import pe.utp.activos.util.Sesion;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private static final String VISTA = "/WEB-INF/views/login.jsp";

    private final AutenticacionService service = new AutenticacionService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (Sesion.usuario(req) != null) {
            resp.sendRedirect(req.getContextPath() + "/activos");
            return;
        }
        req.getRequestDispatcher(VISTA).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = Formularios.texto(req.getParameter("username"));
        try {
            Usuario u = service.iniciarSesion(username, req.getParameter("password"));
            req.getSession(true);
            req.changeSessionId(); // evita la fijación de sesión
            req.getSession().setAttribute(Sesion.USUARIO, u);
            resp.sendRedirect(req.getContextPath() + "/activos");
        } catch (ServicioException e) {
            req.setAttribute("error", e.getMessage());
            req.setAttribute("username", username);
            req.getRequestDispatcher(VISTA).forward(req, resp);
        }
    }
}
