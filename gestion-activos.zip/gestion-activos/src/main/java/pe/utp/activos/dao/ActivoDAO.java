package pe.utp.activos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import pe.utp.activos.config.ConexionDB;
import pe.utp.activos.model.Activo;

/** Acceso a la tabla activo. Todas las consultas usan PreparedStatement. */
public class ActivoDAO {

    private static final String BASE =
            "SELECT a.id_activo, a.codigo, a.nombre, a.marca, a.modelo, a.nro_serie, "
            + "a.id_categoria, c.nombre AS categoria, a.estado, a.fecha_adquisicion, a.valor "
            + "FROM activo a JOIN categoria c ON c.id_categoria = a.id_categoria ";

    public List<Activo> listar(String filtro) throws SQLException {
        String sql = BASE + "WHERE a.codigo LIKE ? OR a.nombre LIKE ? OR a.marca LIKE ? OR c.nombre LIKE ? "
                + "ORDER BY a.codigo";
        String like = "%" + (filtro == null ? "" : filtro.trim()) + "%";
        List<Activo> lista = new ArrayList<>();
        try (Connection cn = ConexionDB.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            for (int i = 1; i <= 4; i++) {
                ps.setString(i, like);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapear(rs));
                }
            }
        }
        return lista;
    }

    public List<Activo> listarPorEstado(String estado) throws SQLException {
        String sql = BASE + "WHERE a.estado = ? ORDER BY a.codigo";
        List<Activo> lista = new ArrayList<>();
        try (Connection cn = ConexionDB.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, estado);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapear(rs));
                }
            }
        }
        return lista;
    }

    public Activo buscarPorId(int id) throws SQLException {
        try (Connection cn = ConexionDB.getConexion()) {
            return buscarPorId(cn, id, false);
        }
    }

    /** Dentro de una transacción: bloquea la fila para que nadie más la modifique a la vez. */
    public Activo buscarParaActualizar(Connection cn, int id) throws SQLException {
        return buscarPorId(cn, id, true);
    }

    private Activo buscarPorId(Connection cn, int id, boolean bloquear) throws SQLException {
        String sql = BASE + "WHERE a.id_activo = ?" + (bloquear ? " FOR UPDATE" : "");
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    public void insertar(Activo a) throws SQLException {
        String sql = "INSERT INTO activo (codigo, nombre, marca, modelo, nro_serie, id_categoria, "
                + "estado, fecha_adquisicion, valor) VALUES (?, ?, ?, ?, ?, ?, 'DISPONIBLE', ?, ?)";
        try (Connection cn = ConexionDB.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, a.getCodigo());
            ps.setString(2, a.getNombre());
            ps.setString(3, a.getMarca());
            ps.setString(4, a.getModelo());
            ps.setString(5, a.getNroSerie());
            ps.setInt(6, a.getIdCategoria());
            ps.setObject(7, a.getFechaAdquisicion());
            ps.setBigDecimal(8, a.getValor());
            ps.executeUpdate();
        }
    }

    public void actualizar(Activo a) throws SQLException {
        String sql = "UPDATE activo SET codigo = ?, nombre = ?, marca = ?, modelo = ?, nro_serie = ?, "
                + "id_categoria = ?, fecha_adquisicion = ?, valor = ? WHERE id_activo = ?";
        try (Connection cn = ConexionDB.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, a.getCodigo());
            ps.setString(2, a.getNombre());
            ps.setString(3, a.getMarca());
            ps.setString(4, a.getModelo());
            ps.setString(5, a.getNroSerie());
            ps.setInt(6, a.getIdCategoria());
            ps.setObject(7, a.getFechaAdquisicion());
            ps.setBigDecimal(8, a.getValor());
            ps.setInt(9, a.getIdActivo());
            ps.executeUpdate();
        }
    }

    public void cambiarEstado(int id, String estado) throws SQLException {
        try (Connection cn = ConexionDB.getConexion()) {
            cambiarEstado(cn, id, estado);
        }
    }

    /** Versión para usar dentro de una transacción abierta por el servicio. */
    public void cambiarEstado(Connection cn, int id, String estado) throws SQLException {
        try (PreparedStatement ps = cn.prepareStatement("UPDATE activo SET estado = ? WHERE id_activo = ?")) {
            ps.setString(1, estado);
            ps.setInt(2, id);
            ps.executeUpdate();
        }
    }

    private Activo mapear(ResultSet rs) throws SQLException {
        Activo a = new Activo();
        a.setIdActivo(rs.getInt("id_activo"));
        a.setCodigo(rs.getString("codigo"));
        a.setNombre(rs.getString("nombre"));
        a.setMarca(rs.getString("marca"));
        a.setModelo(rs.getString("modelo"));
        a.setNroSerie(rs.getString("nro_serie"));
        a.setIdCategoria(rs.getInt("id_categoria"));
        a.setCategoria(rs.getString("categoria"));
        a.setEstado(rs.getString("estado"));
        a.setFechaAdquisicion(rs.getObject("fecha_adquisicion", LocalDate.class));
        a.setValor(rs.getBigDecimal("valor"));
        return a;
    }
}
