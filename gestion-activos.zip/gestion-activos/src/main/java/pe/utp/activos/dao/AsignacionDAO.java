package pe.utp.activos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import pe.utp.activos.config.ConexionDB;
import pe.utp.activos.model.Asignacion;

public class AsignacionDAO {

    private static final String BASE =
            "SELECT s.id_asignacion, s.id_activo, s.id_empleado, s.fecha_asignacion, s.fecha_devolucion, "
            + "s.observacion, a.codigo, a.nombre AS activo, CONCAT(e.nombres, ' ', e.apellidos) AS empleado "
            + "FROM asignacion s "
            + "JOIN activo a ON a.id_activo = s.id_activo "
            + "JOIN empleado e ON e.id_empleado = s.id_empleado ";

    /** Primero las asignaciones vigentes y luego el historial, de la más reciente a la más antigua. */
    public List<Asignacion> listar() throws SQLException {
        String sql = BASE + "ORDER BY (s.fecha_devolucion IS NOT NULL), s.fecha_asignacion DESC, s.id_asignacion DESC";
        List<Asignacion> lista = new ArrayList<>();
        try (Connection cn = ConexionDB.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }

    /** Se usa dentro de una transacción: bloquea la asignación mientras se registra la devolución. */
    public Asignacion buscarParaActualizar(Connection cn, int id) throws SQLException {
        try (PreparedStatement ps = cn.prepareStatement(BASE + "WHERE s.id_asignacion = ? FOR UPDATE")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    public void insertar(Connection cn, Asignacion a) throws SQLException {
        String sql = "INSERT INTO asignacion (id_activo, id_empleado, fecha_asignacion, observacion) "
                + "VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, a.getIdActivo());
            ps.setInt(2, a.getIdEmpleado());
            ps.setObject(3, a.getFechaAsignacion());
            ps.setString(4, a.getObservacion());
            ps.executeUpdate();
        }
    }

    public void registrarDevolucion(Connection cn, int idAsignacion, LocalDate fecha) throws SQLException {
        try (PreparedStatement ps = cn.prepareStatement(
                "UPDATE asignacion SET fecha_devolucion = ? WHERE id_asignacion = ?")) {
            ps.setObject(1, fecha);
            ps.setInt(2, idAsignacion);
            ps.executeUpdate();
        }
    }

    private Asignacion mapear(ResultSet rs) throws SQLException {
        Asignacion a = new Asignacion();
        a.setIdAsignacion(rs.getInt("id_asignacion"));
        a.setIdActivo(rs.getInt("id_activo"));
        a.setIdEmpleado(rs.getInt("id_empleado"));
        a.setFechaAsignacion(rs.getObject("fecha_asignacion", LocalDate.class));
        a.setFechaDevolucion(rs.getObject("fecha_devolucion", LocalDate.class));
        a.setObservacion(rs.getString("observacion"));
        a.setActivoCodigo(rs.getString("codigo"));
        a.setActivoNombre(rs.getString("activo"));
        a.setEmpleadoNombre(rs.getString("empleado"));
        return a;
    }
}
