package pe.utp.activos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.utp.activos.config.ConexionDB;
import pe.utp.activos.model.Empleado;

public class EmpleadoDAO {

    private static final String BASE =
            "SELECT e.id_empleado, e.dni, e.nombres, e.apellidos, e.correo, e.cargo, "
            + "e.id_departamento, d.nombre AS departamento "
            + "FROM empleado e JOIN departamento d ON d.id_departamento = e.id_departamento ";

    public List<Empleado> listar() throws SQLException {
        List<Empleado> lista = new ArrayList<>();
        try (Connection cn = ConexionDB.getConexion();
             PreparedStatement ps = cn.prepareStatement(BASE + "ORDER BY e.apellidos, e.nombres");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }

    public Empleado buscarPorId(int id) throws SQLException {
        try (Connection cn = ConexionDB.getConexion();
             PreparedStatement ps = cn.prepareStatement(BASE + "WHERE e.id_empleado = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    public void insertar(Empleado e) throws SQLException {
        String sql = "INSERT INTO empleado (dni, nombres, apellidos, correo, cargo, id_departamento) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection cn = ConexionDB.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, e.getDni());
            ps.setString(2, e.getNombres());
            ps.setString(3, e.getApellidos());
            ps.setString(4, e.getCorreo());
            ps.setString(5, e.getCargo());
            ps.setInt(6, e.getIdDepartamento());
            ps.executeUpdate();
        }
    }

    private Empleado mapear(ResultSet rs) throws SQLException {
        Empleado e = new Empleado();
        e.setIdEmpleado(rs.getInt("id_empleado"));
        e.setDni(rs.getString("dni"));
        e.setNombres(rs.getString("nombres"));
        e.setApellidos(rs.getString("apellidos"));
        e.setCorreo(rs.getString("correo"));
        e.setCargo(rs.getString("cargo"));
        e.setIdDepartamento(rs.getInt("id_departamento"));
        e.setDepartamento(rs.getString("departamento"));
        return e;
    }
}
