package pe.utp.activos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import pe.utp.activos.config.ConexionDB;
import pe.utp.activos.model.Usuario;

public class UsuarioDAO {

    public Usuario buscarPorUsername(String username) throws SQLException {
        String sql = "SELECT id_usuario, username, password_hash, rol FROM usuario WHERE username = ?";
        try (Connection cn = ConexionDB.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }
                Usuario u = new Usuario();
                u.setIdUsuario(rs.getInt("id_usuario"));
                u.setUsername(rs.getString("username"));
                u.setPasswordHash(rs.getString("password_hash"));
                u.setRol(rs.getString("rol"));
                return u;
            }
        }
    }
}
