package pe.utp.activos.model;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Un bien de la empresa. Estados posibles: DISPONIBLE, ASIGNADO, MANTENIMIENTO, BAJA. */
public class Activo {

    public static final String DISPONIBLE = "DISPONIBLE";
    public static final String ASIGNADO = "ASIGNADO";
    public static final String MANTENIMIENTO = "MANTENIMIENTO";
    public static final String BAJA = "BAJA";

    private int idActivo;
    private String codigo;
    private String nombre;
    private String marca;
    private String modelo;
    private String nroSerie;
    private int idCategoria;
    private String categoria;
    private String estado = DISPONIBLE;
    private LocalDate fechaAdquisicion;
    private BigDecimal valor;

    public int getIdActivo() { return idActivo; }
    public void setIdActivo(int idActivo) { this.idActivo = idActivo; }
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getMarca() { return marca; }
    public void setMarca(String marca) { this.marca = marca; }
    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }
    public String getNroSerie() { return nroSerie; }
    public void setNroSerie(String nroSerie) { this.nroSerie = nroSerie; }
    public int getIdCategoria() { return idCategoria; }
    public void setIdCategoria(int idCategoria) { this.idCategoria = idCategoria; }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public LocalDate getFechaAdquisicion() { return fechaAdquisicion; }
    public void setFechaAdquisicion(LocalDate fechaAdquisicion) { this.fechaAdquisicion = fechaAdquisicion; }
    public BigDecimal getValor() { return valor; }
    public void setValor(BigDecimal valor) { this.valor = valor; }
}
