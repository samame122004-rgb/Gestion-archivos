package pe.utp.activos.model;

import java.time.LocalDate;

/** Entrega de un activo a un empleado. Si fechaDevolucion es null, la asignación está vigente. */
public class Asignacion {

    private int idAsignacion;
    private int idActivo;
    private int idEmpleado;
    private LocalDate fechaAsignacion;
    private LocalDate fechaDevolucion;
    private String observacion;

    // Datos de las tablas relacionadas, para mostrar en los listados
    private String activoCodigo;
    private String activoNombre;
    private String empleadoNombre;

    public boolean isVigente() {
        return fechaDevolucion == null;
    }

    public int getIdAsignacion() { return idAsignacion; }
    public void setIdAsignacion(int idAsignacion) { this.idAsignacion = idAsignacion; }
    public int getIdActivo() { return idActivo; }
    public void setIdActivo(int idActivo) { this.idActivo = idActivo; }
    public int getIdEmpleado() { return idEmpleado; }
    public void setIdEmpleado(int idEmpleado) { this.idEmpleado = idEmpleado; }
    public LocalDate getFechaAsignacion() { return fechaAsignacion; }
    public void setFechaAsignacion(LocalDate fechaAsignacion) { this.fechaAsignacion = fechaAsignacion; }
    public LocalDate getFechaDevolucion() { return fechaDevolucion; }
    public void setFechaDevolucion(LocalDate fechaDevolucion) { this.fechaDevolucion = fechaDevolucion; }
    public String getObservacion() { return observacion; }
    public void setObservacion(String observacion) { this.observacion = observacion; }
    public String getActivoCodigo() { return activoCodigo; }
    public void setActivoCodigo(String activoCodigo) { this.activoCodigo = activoCodigo; }
    public String getActivoNombre() { return activoNombre; }
    public void setActivoNombre(String activoNombre) { this.activoNombre = activoNombre; }
    public String getEmpleadoNombre() { return empleadoNombre; }
    public void setEmpleadoNombre(String empleadoNombre) { this.empleadoNombre = empleadoNombre; }
}
