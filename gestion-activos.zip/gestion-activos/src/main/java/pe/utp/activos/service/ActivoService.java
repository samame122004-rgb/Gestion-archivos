package pe.utp.activos.service;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import pe.utp.activos.dao.ActivoDAO;
import pe.utp.activos.dao.CategoriaDAO;
import pe.utp.activos.model.Activo;
import pe.utp.activos.model.Categoria;

/** Reglas de negocio del módulo de activos. */
public class ActivoService {

    private static final Logger LOG = Logger.getLogger(ActivoService.class.getName());
    private static final int CODIGO_DUPLICADO = 1062; // código de error de MySQL

    private final ActivoDAO activoDAO = new ActivoDAO();
    private final CategoriaDAO categoriaDAO = new CategoriaDAO();

    public List<Activo> listar(String filtro) throws ServicioException {
        try {
            return activoDAO.listar(filtro);
        } catch (SQLException e) {
            throw fallo("No se pudo consultar los activos", e);
        }
    }

    public List<Activo> listarDisponibles() throws ServicioException {
        try {
            return activoDAO.listarPorEstado(Activo.DISPONIBLE);
        } catch (SQLException e) {
            throw fallo("No se pudo consultar los activos disponibles", e);
        }
    }

    public Activo buscar(int id) throws ServicioException {
        try {
            Activo a = activoDAO.buscarPorId(id);
            if (a == null) {
                throw new ServicioException("El activo solicitado no existe");
            }
            return a;
        } catch (SQLException e) {
            throw fallo("No se pudo consultar el activo", e);
        }
    }

    public List<Categoria> listarCategorias() throws ServicioException {
        try {
            return categoriaDAO.listar();
        } catch (SQLException e) {
            throw fallo("No se pudo consultar las categorías", e);
        }
    }

    public void guardar(Activo a) throws ServicioException {
        validar(a);
        try {
            if (a.getIdActivo() == 0) {
                activoDAO.insertar(a);
            } else {
                buscar(a.getIdActivo()); // confirma que existe
                activoDAO.actualizar(a);
            }
        } catch (SQLException e) {
            if (e.getErrorCode() == CODIGO_DUPLICADO) {
                throw new ServicioException("Ya existe un activo con el código " + a.getCodigo());
            }
            throw fallo("No se pudo guardar el activo", e);
        }
    }

    /**
     * Cambia el estado manual de un activo. Un activo ASIGNADO no se toca (primero hay que
     * registrar su devolución) y un activo dado de BAJA ya no vuelve a usarse.
     */
    public void cambiarEstado(int id, String nuevoEstado) throws ServicioException {
        if (!Activo.DISPONIBLE.equals(nuevoEstado) && !Activo.MANTENIMIENTO.equals(nuevoEstado)
                && !Activo.BAJA.equals(nuevoEstado)) {
            throw new ServicioException("Estado no permitido: " + nuevoEstado);
        }
        Activo actual = buscar(id);
        if (Activo.ASIGNADO.equals(actual.getEstado())) {
            throw new ServicioException("El activo está asignado: registre primero su devolución");
        }
        if (Activo.BAJA.equals(actual.getEstado())) {
            throw new ServicioException("El activo ya fue dado de baja");
        }
        try {
            activoDAO.cambiarEstado(id, nuevoEstado);
        } catch (SQLException e) {
            throw fallo("No se pudo cambiar el estado del activo", e);
        }
    }

    private void validar(Activo a) throws ServicioException {
        if (a.getCodigo() == null) {
            throw new ServicioException("El código es obligatorio");
        }
        if (a.getNombre() == null) {
            throw new ServicioException("El nombre es obligatorio");
        }
        if (a.getIdCategoria() <= 0) {
            throw new ServicioException("Seleccione una categoría");
        }
        if (a.getValor() != null && a.getValor().compareTo(BigDecimal.ZERO) < 0) {
            throw new ServicioException("El valor no puede ser negativo");
        }
    }

    private ServicioException fallo(String mensaje, SQLException e) {
        LOG.log(Level.SEVERE, mensaje, e);
        return new ServicioException(mensaje + ". Revise la conexión con la base de datos.", e);
    }
}
