package pe.utp.activos.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import pe.utp.activos.config.ConexionDB;
import pe.utp.activos.dao.ActivoDAO;
import pe.utp.activos.dao.AsignacionDAO;
import pe.utp.activos.dao.EmpleadoDAO;
import pe.utp.activos.model.Activo;
import pe.utp.activos.model.Asignacion;

/**
 * Asignar o devolver un activo cambia dos tablas (asignacion y activo). Por eso cada operación
 * se ejecuta en una transacción: o se guardan las dos cosas, o ninguna.
 */
public class AsignacionService {

    private static final Logger LOG = Logger.getLogger(AsignacionService.class.getName());

    private final AsignacionDAO asignacionDAO = new AsignacionDAO();
    private final ActivoDAO activoDAO = new ActivoDAO();
    private final EmpleadoDAO empleadoDAO = new EmpleadoDAO();

    public List<Asignacion> listar() throws ServicioException {
        try {
            return asignacionDAO.listar();
        } catch (SQLException e) {
            throw fallo("No se pudo consultar las asignaciones", e);
        }
    }

    public void asignar(int idActivo, int idEmpleado, LocalDate fecha, String observacion)
            throws ServicioException {
        if (idActivo <= 0 || idEmpleado <= 0) {
            throw new ServicioException("Seleccione un activo y un empleado");
        }
        if (fecha == null) {
            throw new ServicioException("Ingrese una fecha de asignación válida");
        }
        if (fecha.isAfter(LocalDate.now())) {
            throw new ServicioException("La fecha de asignación no puede ser futura");
        }
        try {
            if (empleadoDAO.buscarPorId(idEmpleado) == null) {
                throw new ServicioException("El empleado seleccionado no existe");
            }
        } catch (SQLException e) {
            throw fallo("No se pudo validar el empleado", e);
        }

        try (Connection cn = ConexionDB.getConexion()) {
            cn.setAutoCommit(false);
            try {
                Activo activo = activoDAO.buscarParaActualizar(cn, idActivo);
                if (activo == null) {
                    throw new ServicioException("El activo seleccionado no existe");
                }
                if (!Activo.DISPONIBLE.equals(activo.getEstado())) {
                    throw new ServicioException("El activo " + activo.getCodigo()
                            + " no está disponible (estado: " + activo.getEstado() + ")");
                }
                Asignacion a = new Asignacion();
                a.setIdActivo(idActivo);
                a.setIdEmpleado(idEmpleado);
                a.setFechaAsignacion(fecha);
                a.setObservacion(observacion);
                asignacionDAO.insertar(cn, a);
                activoDAO.cambiarEstado(cn, idActivo, Activo.ASIGNADO);
                cn.commit();
            } catch (ServicioException | SQLException | RuntimeException e) {
                cn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw fallo("No se pudo registrar la asignación", e);
        }
    }

    public void devolver(int idAsignacion, LocalDate fecha) throws ServicioException {
        if (fecha == null) {
            throw new ServicioException("Ingrese una fecha de devolución válida");
        }
        try (Connection cn = ConexionDB.getConexion()) {
            cn.setAutoCommit(false);
            try {
                Asignacion a = asignacionDAO.buscarParaActualizar(cn, idAsignacion);
                if (a == null) {
                    throw new ServicioException("La asignación no existe");
                }
                if (!a.isVigente()) {
                    throw new ServicioException("Esta asignación ya fue devuelta");
                }
                if (fecha.isBefore(a.getFechaAsignacion())) {
                    throw new ServicioException("La devolución no puede ser anterior a la asignación");
                }
                asignacionDAO.registrarDevolucion(cn, idAsignacion, fecha);
                activoDAO.cambiarEstado(cn, a.getIdActivo(), Activo.DISPONIBLE);
                cn.commit();
            } catch (ServicioException | SQLException | RuntimeException e) {
                cn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw fallo("No se pudo registrar la devolución", e);
        }
    }

    private ServicioException fallo(String mensaje, SQLException e) {
        LOG.log(Level.SEVERE, mensaje, e);
        return new ServicioException(mensaje + ". Revise la conexión con la base de datos.", e);
    }
}
