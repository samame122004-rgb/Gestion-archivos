package pe.utp.activos.service;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import pe.utp.activos.dao.UsuarioDAO;
import pe.utp.activos.model.Usuario;
import pe.utp.activos.util.PasswordUtil;

public class AutenticacionService {

    private static final Logger LOG = Logger.getLogger(AutenticacionService.class.getName());

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    /** Devuelve el usuario si las credenciales son correctas; si no, lanza ServicioException. */
    public Usuario iniciarSesion(String username, String password) throws ServicioException {
        if (username == null || password == null || password.isEmpty()) {
            throw new ServicioException("Ingrese usuario y contraseña");
        }
        try {
            Usuario u = usuarioDAO.buscarPorUsername(username);
            if (u == null || !u.getPasswordHash().equals(PasswordUtil.sha256(password))) {
                throw new ServicioException("Usuario o contraseña incorrectos");
            }
            return u;
        } catch (SQLException e) {
            LOG.log(Level.SEVERE, "Error al iniciar sesión", e);
            throw new ServicioException("No se pudo conectar con la base de datos", e);
        }
    }
}
