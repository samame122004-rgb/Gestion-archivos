package pe.utp.activos.service;

import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import pe.utp.activos.dao.DepartamentoDAO;
import pe.utp.activos.dao.EmpleadoDAO;
import pe.utp.activos.model.Departamento;
import pe.utp.activos.model.Empleado;

public class EmpleadoService {

    private static final Logger LOG = Logger.getLogger(EmpleadoService.class.getName());
    private static final int CODIGO_DUPLICADO = 1062;

    private final EmpleadoDAO empleadoDAO = new EmpleadoDAO();
    private final DepartamentoDAO departamentoDAO = new DepartamentoDAO();

    public List<Empleado> listar() throws ServicioException {
        try {
            return empleadoDAO.listar();
        } catch (SQLException e) {
            throw fallo("No se pudo consultar los empleados", e);
        }
    }

    public List<Departamento> listarDepartamentos() throws ServicioException {
        try {
            return departamentoDAO.listar();
        } catch (SQLException e) {
            throw fallo("No se pudo consultar los departamentos", e);
        }
    }

    public void registrar(Empleado e) throws ServicioException {
        if (e.getDni() == null || !e.getDni().matches("\\d{8}")) {
            throw new ServicioException("El DNI debe tener exactamente 8 dígitos");
        }
        if (e.getNombres() == null || e.getApellidos() == null) {
            throw new ServicioException("Los nombres y apellidos son obligatorios");
        }
        if (e.getCorreo() == null || !e.getCorreo().contains("@")) {
            throw new ServicioException("Ingrese un correo válido");
        }
        if (e.getIdDepartamento() <= 0) {
            throw new ServicioException("Seleccione un departamento");
        }
        try {
            empleadoDAO.insertar(e);
        } catch (SQLException ex) {
            if (ex.getErrorCode() == CODIGO_DUPLICADO) {
                throw new ServicioException("Ya existe un empleado con ese DNI o correo");
            }
            throw fallo("No se pudo registrar el empleado", ex);
        }
    }

    private ServicioException fallo(String mensaje, SQLException e) {
        LOG.log(Level.SEVERE, mensaje, e);
        return new ServicioException(mensaje + ". Revise la conexión con la base de datos.", e);
    }
}
