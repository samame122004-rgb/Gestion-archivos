package pe.utp.activos.service;

/** Error de regla de negocio o de base de datos, con un mensaje listo para mostrar al usuario. */
public class ServicioException extends Exception {

    private static final long serialVersionUID = 1L;

    public ServicioException(String mensaje) {
        super(mensaje);
    }

    public ServicioException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
