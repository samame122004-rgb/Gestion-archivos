package pe.utp.activos.util;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/** Conversión segura de los parámetros de texto que llegan desde los formularios. */
public final class Formularios {

    private Formularios() {
    }

    /** Devuelve el texto sin espacios sobrantes, o null si viene vacío. */
    public static String texto(String valor) {
        if (valor == null) {
            return null;
        }
        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    public static int entero(String valor, int porDefecto) {
        try {
            return Integer.parseInt(valor.trim());
        } catch (NumberFormatException | NullPointerException e) {
            return porDefecto;
        }
    }

    public static BigDecimal decimal(String valor) {
        try {
            return new BigDecimal(valor.trim());
        } catch (NumberFormatException | NullPointerException e) {
            return null;
        }
    }

    public static LocalDate fecha(String valor) {
        try {
            return LocalDate.parse(valor.trim());
        } catch (DateTimeParseException | NullPointerException e) {
            return null;
        }
    }
}
