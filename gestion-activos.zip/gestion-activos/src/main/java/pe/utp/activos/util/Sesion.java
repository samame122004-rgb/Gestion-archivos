package pe.utp.activos.util;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import pe.utp.activos.model.Usuario;

/** Utilidades de sesión: usuario autenticado y mensajes que sobreviven a una redirección. */
public final class Sesion {

    public static final String USUARIO = "usuario";

    private Sesion() {
    }

    public static Usuario usuario(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        return s == null ? null : (Usuario) s.getAttribute(USUARIO);
    }

    public static boolean esAdmin(HttpServletRequest req) {
        Usuario u = usuario(req);
        return u != null && "ADMIN".equals(u.getRol());
    }

    /** Mensaje de éxito para mostrar tras redirigir (patrón Post/Redirect/Get). */
    public static void exito(HttpServletRequest req, String mensaje) {
        req.getSession().setAttribute("flashExito", mensaje);
    }

    public static void error(HttpServletRequest req, String mensaje) {
        req.getSession().setAttribute("flashError", mensaje);
    }
}
