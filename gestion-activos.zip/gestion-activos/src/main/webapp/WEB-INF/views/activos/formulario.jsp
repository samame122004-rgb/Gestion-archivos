<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="titulo" value="${activo.idActivo == 0 ? 'Registrar activo' : 'Editar activo'}"/>
<%@ include file="/WEB-INF/views/fragmentos/header.jspf" %>

<h1><c:out value="${titulo}"/></h1>
<form class="formulario" method="post" action="${pageContext.request.contextPath}/activos?action=guardar">
    <input type="hidden" name="idActivo" value="${activo.idActivo}">

    <label for="codigo">Código *</label>
    <input id="codigo" name="codigo" maxlength="20" value="<c:out value='${activo.codigo}'/>" required>

    <label for="nombre">Nombre *</label>
    <input id="nombre" name="nombre" maxlength="100" value="<c:out value='${activo.nombre}'/>" required>

    <label for="marca">Marca</label>
    <input id="marca" name="marca" maxlength="60" value="<c:out value='${activo.marca}'/>">

    <label for="modelo">Modelo</label>
    <input id="modelo" name="modelo" maxlength="60" value="<c:out value='${activo.modelo}'/>">

    <label for="nroSerie">Número de serie</label>
    <input id="nroSerie" name="nroSerie" maxlength="60" value="<c:out value='${activo.nroSerie}'/>">

    <label for="idCategoria">Categoría *</label>
    <select id="idCategoria" name="idCategoria" required>
        <option value="">Seleccione...</option>
        <c:forEach var="cat" items="${categorias}">
            <option value="${cat.idCategoria}" ${cat.idCategoria == activo.idCategoria ? 'selected' : ''}>
                <c:out value="${cat.nombre}"/>
            </option>
        </c:forEach>
    </select>

    <label for="fechaAdquisicion">Fecha de adquisición</label>
    <input id="fechaAdquisicion" name="fechaAdquisicion" type="date" value="${activo.fechaAdquisicion}">

    <label for="valor">Valor (S/)</label>
    <input id="valor" name="valor" type="number" min="0" step="0.01" value="${activo.valor}">

    <div class="botones">
        <button class="btn" type="submit">Guardar</button>
        <a class="btn secundario" href="${pageContext.request.contextPath}/activos">Cancelar</a>
    </div>
</form>

<%@ include file="/WEB-INF/views/fragmentos/footer.jspf" %>
