<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="titulo" value="Activos"/>
<%@ include file="/WEB-INF/views/fragmentos/header.jspf" %>

<h1>Activos</h1>
<div class="acciones">
    <form class="buscador" method="get" action="${pageContext.request.contextPath}/activos">
        <input name="q" value="<c:out value='${q}'/>" placeholder="Buscar por código, nombre, marca o categoría">
        <button class="btn secundario" type="submit">Buscar</button>
    </form>
    <a class="btn" href="${pageContext.request.contextPath}/activos?action=nuevo">Registrar activo</a>
</div>

<table>
    <tr>
        <th>Código</th><th>Nombre</th><th>Marca / modelo</th><th>Categoría</th>
        <th>Estado</th><th>Valor (S/)</th><th>Acciones</th>
    </tr>
    <c:forEach var="a" items="${activos}">
        <tr>
            <td><c:out value="${a.codigo}"/></td>
            <td><c:out value="${a.nombre}"/></td>
            <td><c:out value="${a.marca}"/> <c:out value="${a.modelo}"/></td>
            <td><c:out value="${a.categoria}"/></td>
            <td><span class="estado estado-${a.estado}"><c:out value="${a.estado}"/></span></td>
            <td><c:out value="${a.valor}"/></td>
            <td class="fila-acciones">
                <c:if test="${a.estado != 'BAJA'}">
                    <a class="btn pequeno secundario"
                       href="${pageContext.request.contextPath}/activos?action=editar&id=${a.idActivo}">Editar</a>
                </c:if>
                <c:if test="${a.estado == 'DISPONIBLE'}">
                    <form method="post" action="${pageContext.request.contextPath}/activos?action=estado">
                        <input type="hidden" name="id" value="${a.idActivo}">
                        <input type="hidden" name="estado" value="MANTENIMIENTO">
                        <button class="btn pequeno" type="submit">Mantenimiento</button>
                    </form>
                </c:if>
                <c:if test="${a.estado == 'MANTENIMIENTO'}">
                    <form method="post" action="${pageContext.request.contextPath}/activos?action=estado">
                        <input type="hidden" name="id" value="${a.idActivo}">
                        <input type="hidden" name="estado" value="DISPONIBLE">
                        <button class="btn pequeno" type="submit">Habilitar</button>
                    </form>
                </c:if>
                <c:if test="${sessionScope.usuario.rol == 'ADMIN' && (a.estado == 'DISPONIBLE' || a.estado == 'MANTENIMIENTO')}">
                    <form method="post" action="${pageContext.request.contextPath}/activos?action=estado"
                          onsubmit="return confirm('¿Dar de baja este activo? No se puede deshacer.');">
                        <input type="hidden" name="id" value="${a.idActivo}">
                        <input type="hidden" name="estado" value="BAJA">
                        <button class="btn pequeno peligro" type="submit">Dar de baja</button>
                    </form>
                </c:if>
            </td>
        </tr>
    </c:forEach>
    <c:if test="${empty activos}">
        <tr><td class="vacio" colspan="7">No se encontraron activos.</td></tr>
    </c:if>
</table>

<%@ include file="/WEB-INF/views/fragmentos/footer.jspf" %>
