<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="titulo" value="Asignar activo"/>
<%@ include file="/WEB-INF/views/fragmentos/header.jspf" %>

<h1>Asignar activo a un empleado</h1>
<form class="formulario" method="post" action="${pageContext.request.contextPath}/asignaciones?action=asignar">
    <label for="idActivo">Activo disponible *</label>
    <select id="idActivo" name="idActivo" required>
        <option value="">Seleccione...</option>
        <c:forEach var="a" items="${activos}">
            <option value="${a.idActivo}" ${a.idActivo == param.idActivo ? 'selected' : ''}>
                <c:out value="${a.codigo}"/> · <c:out value="${a.nombre}"/>
            </option>
        </c:forEach>
    </select>
    <c:if test="${empty activos}">
        <p class="ayuda">No hay activos disponibles para asignar.</p>
    </c:if>

    <label for="idEmpleado">Empleado *</label>
    <select id="idEmpleado" name="idEmpleado" required>
        <option value="">Seleccione...</option>
        <c:forEach var="e" items="${empleados}">
            <option value="${e.idEmpleado}" ${e.idEmpleado == param.idEmpleado ? 'selected' : ''}>
                <c:out value="${e.nombreCompleto}"/> (<c:out value="${e.departamento}"/>)
            </option>
        </c:forEach>
    </select>

    <label for="fechaAsignacion">Fecha de asignación *</label>
    <input id="fechaAsignacion" name="fechaAsignacion" type="date" max="${hoy}"
           value="${empty param.fechaAsignacion ? hoy : param.fechaAsignacion}" required>

    <label for="observacion">Observación</label>
    <textarea id="observacion" name="observacion" rows="3" maxlength="255"><c:out value="${param.observacion}"/></textarea>

    <div class="botones">
        <button class="btn" type="submit">Asignar</button>
        <a class="btn secundario" href="${pageContext.request.contextPath}/asignaciones">Cancelar</a>
    </div>
</form>

<%@ include file="/WEB-INF/views/fragmentos/footer.jspf" %>
