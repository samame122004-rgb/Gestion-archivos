<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="titulo" value="Asignaciones"/>
<%@ include file="/WEB-INF/views/fragmentos/header.jspf" %>

<h1>Asignaciones</h1>
<div class="acciones">
    <span>Las asignaciones vigentes aparecen primero; las devueltas forman el historial.</span>
    <a class="btn" href="${pageContext.request.contextPath}/asignaciones?action=nueva">Asignar activo</a>
</div>

<table>
    <tr>
        <th>Activo</th><th>Empleado</th><th>Asignado</th><th>Devuelto</th><th>Observación</th><th>Acciones</th>
    </tr>
    <c:forEach var="s" items="${asignaciones}">
        <tr>
            <td><c:out value="${s.activoCodigo}"/> · <c:out value="${s.activoNombre}"/></td>
            <td><c:out value="${s.empleadoNombre}"/></td>
            <td><c:out value="${s.fechaAsignacion}"/></td>
            <td>
                <c:choose>
                    <c:when test="${s.vigente}"><span class="estado estado-ASIGNADO">Vigente</span></c:when>
                    <c:otherwise><c:out value="${s.fechaDevolucion}"/></c:otherwise>
                </c:choose>
            </td>
            <td><c:out value="${s.observacion}"/></td>
            <td class="fila-acciones">
                <c:if test="${s.vigente}">
                    <form method="post" action="${pageContext.request.contextPath}/asignaciones?action=devolver">
                        <input type="hidden" name="idAsignacion" value="${s.idAsignacion}">
                        <input type="hidden" name="fechaDevolucion" value="${hoy}">
                        <button class="btn pequeno" type="submit">Registrar devolución</button>
                    </form>
                </c:if>
            </td>
        </tr>
    </c:forEach>
    <c:if test="${empty asignaciones}">
        <tr><td class="vacio" colspan="6">Todavía no hay asignaciones.</td></tr>
    </c:if>
</table>

<%@ include file="/WEB-INF/views/fragmentos/footer.jspf" %>
