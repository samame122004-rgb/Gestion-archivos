<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="titulo" value="Registrar empleado"/>
<%@ include file="/WEB-INF/views/fragmentos/header.jspf" %>

<h1>Registrar empleado</h1>
<form class="formulario" method="post" action="${pageContext.request.contextPath}/empleados">
    <label for="dni">DNI *</label>
    <input id="dni" name="dni" maxlength="8" pattern="\d{8}" title="8 dígitos"
           value="<c:out value='${empleado.dni}'/>" required>

    <label for="nombres">Nombres *</label>
    <input id="nombres" name="nombres" maxlength="80" value="<c:out value='${empleado.nombres}'/>" required>

    <label for="apellidos">Apellidos *</label>
    <input id="apellidos" name="apellidos" maxlength="80" value="<c:out value='${empleado.apellidos}'/>" required>

    <label for="correo">Correo *</label>
    <input id="correo" name="correo" type="email" maxlength="120" value="<c:out value='${empleado.correo}'/>" required>

    <label for="cargo">Cargo</label>
    <input id="cargo" name="cargo" maxlength="80" value="<c:out value='${empleado.cargo}'/>">

    <label for="idDepartamento">Departamento *</label>
    <select id="idDepartamento" name="idDepartamento" required>
        <option value="">Seleccione...</option>
        <c:forEach var="d" items="${departamentos}">
            <option value="${d.idDepartamento}" ${d.idDepartamento == empleado.idDepartamento ? 'selected' : ''}>
                <c:out value="${d.nombre}"/>
            </option>
        </c:forEach>
    </select>

    <div class="botones">
        <button class="btn" type="submit">Guardar</button>
        <a class="btn secundario" href="${pageContext.request.contextPath}/empleados">Cancelar</a>
    </div>
</form>

<%@ include file="/WEB-INF/views/fragmentos/footer.jspf" %>
