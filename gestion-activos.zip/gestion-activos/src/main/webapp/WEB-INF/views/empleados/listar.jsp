<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="titulo" value="Empleados"/>
<%@ include file="/WEB-INF/views/fragmentos/header.jspf" %>

<h1>Empleados</h1>
<div class="acciones">
    <span></span>
    <c:if test="${sessionScope.usuario.rol == 'ADMIN'}">
        <a class="btn" href="${pageContext.request.contextPath}/empleados?action=nuevo">Registrar empleado</a>
    </c:if>
</div>

<table>
    <tr><th>DNI</th><th>Nombre</th><th>Correo</th><th>Cargo</th><th>Departamento</th></tr>
    <c:forEach var="e" items="${empleados}">
        <tr>
            <td><c:out value="${e.dni}"/></td>
            <td><c:out value="${e.nombreCompleto}"/></td>
            <td><c:out value="${e.correo}"/></td>
            <td><c:out value="${e.cargo}"/></td>
            <td><c:out value="${e.departamento}"/></td>
        </tr>
    </c:forEach>
    <c:if test="${empty empleados}">
        <tr><td class="vacio" colspan="5">No hay empleados registrados.</td></tr>
    </c:if>
</table>

<%@ include file="/WEB-INF/views/fragmentos/footer.jspf" %>
