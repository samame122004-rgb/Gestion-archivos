<%@ page contentType="text/html; charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Iniciar sesión · Gestión de Activos</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilo.css">
</head>
<body>
<div class="login">
    <h1>Gestión de Activos</h1>
    <c:if test="${not empty error}">
        <div class="alerta error"><c:out value="${error}"/></div>
    </c:if>
    <form class="formulario" method="post" action="${pageContext.request.contextPath}/login">
        <label for="username">Usuario</label>
        <input id="username" name="username" value="<c:out value='${username}'/>" required autofocus>
        <label for="password">Contraseña</label>
        <input id="password" name="password" type="password" required>
        <div class="botones">
            <button class="btn" type="submit">Ingresar</button>
        </div>
        <p class="ayuda">Usuarios de prueba: admin / admin123 y gestor / gestor123</p>
    </form>
</div>
</body>
</html>
